"""Mesh-refinement check for the single-spot solution and the crosstalk factor."""
import os
import numpy as np
import parallel_thermal_scan as m

print('case                         peak dT(K/mW)   G(p=1um)  G(p=2um)   grid')
for dr0, dzf in [(40e-9, 25e-9), (25e-9, 20e-9), (15e-9, 12e-9)]:
    m.DR0 = dr0
    rc, Tp, Lth, _ = m.single_spot(100e-9, 1.4, 1.05e6, 20e-6,
                                   dz_film=dzf, verbose=False)
    g1 = m.crosstalk(Tp, rc, 1e-6, 5)
    g2 = m.crosstalk(Tp, rc, 2e-6, 5)
    print(f'dr={dr0*1e9:4.0f} nm, dz_film={dzf*1e9:3.0f} nm   {Tp[0]:10.2f} '
          f'{g1:11.3f} {g2:9.3f}   {len(rc)}x?')
    # report actual grid
