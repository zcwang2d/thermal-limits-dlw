"""Time-step convergence of the single-spot response and crosstalk factor."""
import json
import os

import parallel_thermal_scan as m


def main():
    rows = []
    reference = None
    for nt in (30, 60, 120, 240):
        rc, tp, _, _ = m.single_spot(100e-9, 1.4, 1.05e6, 20e-6,
                                     nt=nt, verbose=False)
        row = {
            'nt': nt,
            'dt_us': 20.0 / nt,
            'peak_K_per_mW': float(tp[0]),
            'G_p1um': float(m.crosstalk(tp, rc, 1e-6, 5)),
            'G_p2um': float(m.crosstalk(tp, rc, 2e-6, 5)),
        }
        if nt == 240:
            reference = row
        rows.append(row)

    for row in rows:
        for key in ('peak_K_per_mW', 'G_p1um', 'G_p2um'):
            row[key + '_rel_change_from_nt240'] = row[key] / reference[key] - 1.0

    out = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                       'data', 'timestep_convergence.json')
    with open(out, 'w', encoding='utf-8') as fh:
        json.dump(rows, fh, indent=1)

    print('nt   dt(us)   peak(K/mW)   G(1um)   G(2um)   peak change   G1 change')
    for row in rows:
        print(f"{row['nt']:3d}  {row['dt_us']:7.4f}  {row['peak_K_per_mW']:10.3f}  "
              f"{row['G_p1um']:7.4f}  {row['G_p2um']:7.4f}  "
              f"{100 * row['peak_K_per_mW_rel_change_from_nt240']:+8.3f}%  "
              f"{100 * row['G_p1um_rel_change_from_nt240']:+8.3f}%")
    print('wrote', out)


if __name__ == '__main__':
    main()
