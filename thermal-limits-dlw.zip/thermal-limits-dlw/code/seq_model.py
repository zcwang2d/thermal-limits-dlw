# -*- coding: utf-8 -*-
"""Sequential (raster) write model, shared by the scan drivers and the figure set.

A real DLW tool writes an array point by point, so a pixel sees its neighbours
at staggered instants.  With Lambda = dt_point / tau and the row-major order,
neighbour k contributes its radial history shifted by lag = (k - k_c) Lambda tau.
"""

import numpy as np


def G_sequential(TS, rc, p, mh, lam, tau, dt, nt):
    """Crosstalk factor of a raster-scanned M x M array.

    TS   : (nsteps, nradial) surface-temperature history of one spot,
           integrated over more than tau so that the cooling tail is available.
    rc   : radial grid (m).
    p    : pitch (m);  mh : half-width so that M = 2 mh + 1.
    lam  : Lambda = dt_point / tau.
    dt   : time step of TS;  nt : number of steps inside the dwell window.
    """
    M = 2 * mh + 1
    i = np.arange(-mh, mh + 1)
    X, Y = np.meshgrid(i, i)
    d = p * np.hypot(X, Y)
    ks = (Y + mh) * M + (X + mh)
    kc = mh * M + mh
    nsteps = TS.shape[0]
    tq = np.arange(nsteps) * dt

    # the radial history is cached once per distinct distance
    uniq = np.unique(np.round(d[d > 0] * 1e9).astype(int))
    cache = {}
    for u in uniq:
        dd = u * 1e-9
        cache[u] = np.array([np.interp(dd, rc, TS[s, :], right=0.0)
                             for s in range(nsteps)])

    acc = np.zeros(nsteps)
    for a in range(M):
        for b in range(M):
            if d[a, b] <= 0:
                continue
            key = int(round(d[a, b] * 1e9))
            lag = (ks[a, b] - kc) * lam * tau
            pos = (tq - lag) / dt
            ok = (pos >= 0) & (pos <= nsteps - 1)
            if ok.any():
                acc[ok] += np.interp(pos[ok], np.arange(nsteps), cache[key])

    series = TS[:nt, 0] + acc[:nt]
    return series.max() / TS[:nt, 0].max()


def lambda_threshold(TS, rc, p, mh, tau, dt, nt, criterion=1.05):
    """Return the last Lambda crossing of criterion, robust to time-grid oscillations.

    A direct bisection can converge to a spurious earlier crossing when a neighbour
    switches on or off between samples. We therefore locate the last non-compliant
    point on a coarse grid and refine only that final transition.
    """
    simultaneous = G_sequential(TS, rc, p, mh, 0.0, tau, dt, nt)
    if simultaneous <= criterion:
        return None

    last_bad = None
    for lam in np.linspace(0.0, 2.0, 201):
        if G_sequential(TS, rc, p, mh, lam, tau, dt, nt) > criterion:
            last_bad = lam
    if last_bad is None:
        return 0.0

    # Keep the last non-compliant sample rather than bisecting a non-monotonic curve.
    for lam in np.arange(last_bad, min(last_bad + 0.01, 2.0) + 0.0005, 0.0005):
        if G_sequential(TS, rc, p, mh, lam, tau, dt, nt) > criterion:
            last_bad = lam
    return last_bad
