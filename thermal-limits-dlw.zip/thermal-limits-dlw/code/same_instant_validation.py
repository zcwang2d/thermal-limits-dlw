"""Verify peak-stitched and same-instant simultaneous-array superposition."""
import json
import os

import numpy as np

import parallel_thermal_scan as P

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, 'data', 'same_instant_validation.json')
PITCHES = (0.5, 0.75, 1.0, 1.5, 2.0, 3.0, 4.0, 6.0, 8.0, 12.0)
DWELLS = (1e-6, 5e-6, 20e-6, 100e-6)


def same_instant_g(ts, rc, pitch, half_width=5):
    i = np.arange(-half_width, half_width + 1)
    x, y = np.meshgrid(i, i)
    distances = pitch * np.hypot(x, y).ravel()
    distances = distances[distances > 0]
    nt = ts.shape[0]
    neighbours = np.zeros(nt)
    for distance in distances:
        neighbours += np.array([P.sample_radial(distance, rc, ts[k, :])
                                for k in range(nt)])
    series = ts[:, 0] + neighbours
    return float(series.max() / ts[:, 0].max())


def main():
    rows = []
    for substrate, params in P.SUBS.items():
        for tau in DWELLS:
            rc, tp, _, ts = P.single_spot(100e-9, params['k'], params['rho_c'], tau,
                                          verbose=False)
            for pitch_um in PITCHES:
                stitched = float(P.crosstalk(tp, rc, pitch_um * 1e-6, 5))
                aligned = same_instant_g(ts, rc, pitch_um * 1e-6)
                rows.append({
                    'substrate': substrate,
                    'tau_us': tau * 1e6,
                    'pitch_um': pitch_um,
                    'M': 11,
                    'G_peak_stitched': stitched,
                    'G_same_instant': aligned,
                    'relative_difference': aligned / stitched - 1.0,
                })
    max_row = max(rows, key=lambda row: abs(row['relative_difference']))
    result = {
        'description': ('Peak-stitched versus strict same-instant simultaneous-array G; '
                        'three substrates, four dwells and ten pitches for an 11 x 11 array.'),
        'case_count': len(rows),
        'max_absolute_relative_difference': abs(max_row['relative_difference']),
        'max_difference_case': max_row,
        'rows': rows,
    }
    with open(OUT, 'w', encoding='utf-8') as handle:
        json.dump(result, handle, indent=1)
    print('cases:', len(rows))
    print('max absolute relative difference:', abs(max_row['relative_difference']))
    print('case:', max_row)
    print('wrote', OUT)


if __name__ == '__main__':
    main()
