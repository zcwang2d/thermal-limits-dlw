# -*- coding: utf-8 -*-
"""Robustness of the crosstalk result to the absolute film conductivity.

Independent measurements place the amorphous Sb2S3 film conductivity in a
range (roughly 0.3-0.6 W m^-1 K^-1) that is higher than the baseline value
adopted in the model (0.19 W m^-1 K^-1). Instead of defending a single number,
the array factor is recomputed over a factor range that spans both the low
baseline and the measured amorphous range, so the conclusion can be stated as a
robust interval rather than a point estimate.
"""

import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import parallel_thermal_scan as P

H = 100e-9
TAU = 20e-6
PITCH = 1e-6
MH = 5
SUB = 'silica'
sp = P.SUBS[SUB]
K0 = P.K_TH_A

# wide enough to cover k_film from ~0.05 up to ~0.6 W/mK
FACTORS = (0.25, 0.5, 0.7, 1.0, 1.3, 1.6, 2.0, 2.5, 3.0)

rows = []
for f in FACTORS:
    rc, Tp, Lth, TS = P.single_spot(H, sp['k'], sp['rho_c'], TAU, verbose=False,
                                    k_film=f * K0)
    g = P.crosstalk(Tp, rc, PITCH, MH)
    rows.append((f, f * K0, g, Tp[0], Lth * 1e6))
    print(f'factor {f:4.2f}  k={f*K0:6.4f}  G={g:7.4f}  T0={Tp[0]:7.2f}  '
          f'Lth={Lth*1e6:6.3f}')

g0 = next(r[2] for r in rows if abs(r[0] - 1.0) < 1e-12)
print('\nrelative change of G against the baseline k0 = 0.19:')
for f, k, g, t0, l in rows:
    print(f'factor {f:4.2f}  k={k:6.4f}  G={g:7.4f}  dG/G0={ (g-g0)/g0*100:+7.2f}%')

out = os.path.join(os.path.dirname(HERE), 'data', 'conductivity_robustness.json')
json.dump([{'factor': f, 'k_film': k, 'G': g, 'T0': t0, 'Lth_um': l}
           for f, k, g, t0, l in rows], open(out, 'w'), indent=1)
print('\nsaved', out)
