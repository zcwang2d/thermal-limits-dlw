# -*- coding: utf-8 -*-
"""Linearization boundary under phase-change conductivity variation.

The film conductivity changes between amorphous and crystalline states.  Rather
than extrapolate the first-order sensitivity, the array factor is recomputed at
each conductivity, and the true G(k) is compared with the one-term Taylor
prediction to locate where the constant-property (linear) treatment fails.
"""

import json
import os
import sys
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import parallel_thermal_scan as P

H = 100e-9
TAU = 20e-6
PITCH = 1e-6
MH = 5
SUB = 'silica'
sp = P.SUBS[SUB]
K0 = P.K_TH_A

FACTORS = (0.25, 0.4, 0.55, 0.7, 0.85, 1.0, 1.15, 1.3, 1.6, 2.0)

rows = []
for f in FACTORS:
    rc, Tp, Lth, TS = P.single_spot(H, sp['k'], sp['rho_c'], TAU, verbose=False,
                                    k_film=f * K0)
    g = P.crosstalk(Tp, rc, PITCH, MH)
    rows.append((f, f * K0, g, Tp[0], Lth * 1e6))
    print(f'factor {f:5.2f}  k={f*K0:6.4f}  G={g:7.4f}  T0={Tp[0]:7.2f}  '
          f'Lth={Lth*1e6:6.3f}')

# numerical derivative at factor 1 from the two bracketing points
def g_at(f):
    rc, Tp, Lth, TS = P.single_spot(H, sp['k'], sp['rho_c'], TAU, verbose=False,
                                    k_film=f * K0)
    return P.crosstalk(Tp, rc, PITCH, MH)

g1 = g_at(1.0)
gl, gh = g_at(0.85), g_at(1.15)
dG = (gh - gl) / (0.30)
print('\nfirst-order slope dG/df at 1 =', round(dG, 4))
print('factor   G_true    G_taylor   rel.error')
for f, k, g, t0, l in rows:
    gt = g1 + dG * (f - 1)
    print(f'{f:5.2f}  {g:7.4f}  {gt:7.4f}   {(gt-g)/g*100:+7.2f}%')

json.dump([{'factor': f, 'k_film': k, 'G': g, 'T0': t0, 'Lth_um': l}
           for f, k, g, t0, l in rows],
          open(os.path.join(os.path.dirname(HERE), 'data', 'linearity_boundary.json'),
               'w'), indent=1)
print('\nsaved linearity_boundary.json')
