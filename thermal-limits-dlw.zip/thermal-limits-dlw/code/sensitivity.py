"""One-at-a-time sensitivity of the crosstalk factor to the assumed properties."""
import os
import numpy as np
import parallel_thermal_scan as m

BASE = dict(k_film=0.19, rho_c=1.40e6, k_ext=0.06)
PERT = [0.7, 1.0, 1.3]

def run(k_film=BASE['k_film'], rho_c=BASE['rho_c'], k_ext=BASE['k_ext']):
    m.K_EXT = k_ext
    m.RHO_C_F = rho_c
    rc, Tp, Lth, _ = m.single_spot(100e-9, 1.4, 1.05e6, 20e-6, k_film=k_film, verbose=False)
    g1 = m.crosstalk(Tp, rc, 1e-6, 5)
    g2 = m.crosstalk(Tp, rc, 2e-6, 5)
    return Tp[0], g1, g2

print('case                              peak dT(K/mW)   G(p=1um)  G(p=2um)')
t0, g10, g20 = run()
print(f'{"baseline":34s} {t0:10.2f} {g10:11.3f} {g20:9.3f}')

for name, key in [('k_film', 'k_film'), ('rho_c', 'rho_c'), ('k_ext', 'k_ext')]:
    for f in PERT:
        if f == 1.0:
            continue
        kw = dict(BASE)
        kw[key] = BASE[key] * f
        t, g1, g2 = run(**kw)
        print(f'{name + " x" + str(f):34s} {t:10.2f} {g1:11.3f} {g2:9.3f}'
              f'   (dG(1um)={100*(g1/g10-1):+5.1f}%, dG(2um)={100*(g2/g20-1):+5.1f}%)')
