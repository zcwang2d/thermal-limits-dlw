# -*- coding: utf-8 -*-
"""Smallest feature that can be *withheld* inside a densely written array.

G <= 1.05 says a dense array can be held at one temperature.  It does not say
how small a feature that array can still resolve, because a feature is a
temperature *difference*: the pattern is written by turning pixels off inside a
bright background.  With a strictly positive kernel and non-negative dose, the
contrast at a pixel that is switched off is bounded by how much of its own
temperature it supplied, which is 1/G.  A finite block recovers contrast only
when the block is large enough that its interior is shielded from outside heat.
This script computes that bound as a function of block size.
"""

import os
import sys
import json
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import parallel_thermal_scan as P

H = 100e-9
TAU = 20e-6
MH = 15                      # 31 x 31 array, so the block never spans the whole field
KS = (1, 3, 5, 7, 9, 11, 13)
PLIST = (0.5, 0.75, 1.0, 1.5, 2.0, 3.0, 4.0)
SUBS = ('silica', 'sapphire', 'silicon')


def build(rc, Tp, T0, p_um):
    i = np.arange(-MH, MH + 1)
    coords = np.stack(np.meshgrid(i, i, indexing='ij'), -1).reshape(-1, 2)
    d = (p_um * 1e-6) * np.hypot(coords[:, None, 0] - coords[None, :, 0],
                                 coords[:, None, 1] - coords[None, :, 1])
    return P.sample_radial(d, rc, Tp) / T0, coords


def block_mask(coords, k):
    h = k // 2
    return (np.abs(coords[:, 0]) <= h) & (np.abs(coords[:, 1]) <= h)


res = {}
for sub in SUBS:
    sp = P.SUBS[sub]
    rc, Tp, Lth, TS = P.single_spot(H, sp['k'], sp['rho_c'], TAU, verbose=False)
    T0 = Tp[0]
    print(f'\n{sub}: T0 = {T0:.3f} K/mW')
    for p in PLIST:
        K, coords = build(rc, Tp, T0, p)
        c = MH * (2 * MH + 1) + MH
        T_open = K @ np.ones(len(coords))       # every pixel on
        G = T_open[c]
        cs = []
        for k in KS:
            q = 1.0 - block_mask(coords, k).astype(float)
            T = K @ q
            # darkest point is the block centre
            cs.append((T_open[c] - T[c]) / T_open[c])
        res[f'{sub}|{p}'] = dict(G=round(float(G), 4),
                                 k=list(KS),
                                 contrast=[round(float(v), 4) for v in cs])
        print(f'  p={p:4.2f} um  G(11x11)={G:6.4f}  C(k=1)={cs[0]:6.4f} (=1/G)  '
              f'C(k=3)={cs[1]:6.4f}  C(k=11)={cs[-1]:6.4f}')

out = os.path.join(os.path.dirname(HERE), 'data', 'pattern_limit.json')
with open(out, 'w', encoding='utf-8') as f:
    json.dump(res, f, indent=1)
print('\nwrote', out)

print('\nsmallest block with contrast >= 0.50 (withheld inside a bright array)')
for sub in SUBS:
    line = []
    for p in PLIST:
        d = res[f'{sub}|{p}']
        kmin = next((k for k, c in zip(d['k'], d['contrast']) if c >= 0.50), '-')
        line.append(f'{p}:{kmin}')
    print(f'  {sub:9s} ' + '  '.join(line))
