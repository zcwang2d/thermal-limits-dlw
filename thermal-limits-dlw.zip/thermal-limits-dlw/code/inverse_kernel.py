# -*- coding: utf-8 -*-
"""Structure of the crosstalk operator and its inverse.

Two questions decide whether dose shaping is a paper-worthy contribution or
just a textbook inverse:
  (1) is G-1 separable into a pitch factor times an array-size factor?
  (2) is the inverse kernel localised, i.e. can a small neighbourhood window
      replace the global solve and run in real time on the write head?
"""

import os
import sys
import json
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import parallel_thermal_scan as P

H = 100e-9
TAU = 20e-6
SUB = 'silica'

sp = P.SUBS[SUB]
rc, Tp, Lth, TS = P.single_spot(H, sp['k'], sp['rho_c'], TAU, verbose=False)
T0 = Tp[0]

RECORD = {"film_nm": 100, "dwell_us": 20, "substrate": SUB,
          "singular_values": None, "inverse_kernel_row": [], "windowed": []}
OUT = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                   'data', 'inverse_kernel.json')


def build(MH, p):
    i = np.arange(-MH, MH + 1)
    coords = np.stack(np.meshgrid(i, i, indexing='ij'), -1).reshape(-1, 2)
    d = p * np.hypot(coords[:, None, 0] - coords[None, :, 0],
                     coords[:, None, 1] - coords[None, :, 1])
    return P.sample_radial(d, rc, Tp) / T0, coords, i


# ---------------------------------------------------------------- separability
print('separability test: is G-1 = u(p) v(Mash) ?  (silica, h=100 nm, tau=20 us)')
MH = 30
Mlist = (3, 5, 7, 11, 17, 25, 41, 61)
plist = (0.5, 1.0, 2.0, 4.0)
G = np.zeros((len(plist), len(Mlist)))
for a, p_um in enumerate(plist):
    for b, Mm in enumerate(Mlist):
        K, coords, idx = build(max(Mm // 2, 1), p_um * 1e-6)
        n = Mm * Mm
        # pick the central M x M block of the larger grid
        full = 2 * max(Mm // 2, 1) + 1
        off = (full - Mm) // 2
        sel = [((off + r) * full + (off + c)) for r in range(Mm) for c in range(Mm)]
        G[a, b] = K[np.ix_(sel, sel)].sum(axis=1)[(Mm * Mm) // 2]

D = G - 1
U, S, Vt = np.linalg.svd(D, full_matrices=False)
print(f'  singular values: {np.round(S, 4)}')
print(f'  first mode explains {100*S[0]**2/(S**2).sum():.2f}% of energy')
print(f'  second         {100*S[1]**2/(S**2).sum():.2f}%')
RECORD['singular_values'] = [float(v) for v in S]
RECORD['first_mode_percent'] = float(100 * S[0] ** 2 / (S ** 2).sum())
print('  G-1 matrix (rows=p, cols=M):')
for a, p_um in enumerate(plist):
    print('   p=%.1f um: '%p_um + ' '.join(f'{D[a,b]:7.4f}' for b in range(len(Mlist))))

# ------------------------------------------------------------------ locality
print('\ninverse-kernel locality (silica, h=100 nm, tau=20 us, M=21, p=1 um)')
MH = 10
p = 1e-6
K, coords, idx = build(MH, p)
n = K.shape[0]
Kinv = np.linalg.inv(K)
c = n // 2
row = Kinv[c].reshape(2 * MH + 1, 2 * MH + 1)
print('  rows = |dy|, cols = |dx|, values of K^-1 for the central pixel')
print('      ' + ''.join(f'{"dx="+str(k):>9}' for k in range(0, 5)))
for dy in range(0, 5):
    print(f'  dy={dy} ' + ''.join(f'{row[MH-dy, MH+k]:9.4f}' for k in range(0, 5)))
    RECORD['inverse_kernel_row'].append(
        [float(row[MH - dy, MH + k]) for k in range(0, 5)])

# windowed approximation: keep only |dx|,|dy| <= w and solve
print('\n  windowed compensation: residual ||K q - 1||inf vs window half-width w')
q_full = np.linalg.solve(K, np.ones(n))
for w in (1, 2, 3, 4, 5, 7, 10):
    Kb = np.zeros_like(K)
    for a in range(n):
        ra, ca = divmod(a, 2 * MH + 1)
        for b in range(n):
            rb, cb = divmod(b, 2 * MH + 1)
            if abs(ra - rb) <= w and abs(ca - cb) <= w:
                Kb[a, b] = K[a, b]
    ok = np.abs(Kb).sum(axis=1) > 1e-12
    qb = np.zeros(n)
    qb[ok] = np.linalg.solve(Kb[np.ix_(ok, ok)], np.ones(ok.sum()))
    res = np.abs(K @ qb - 1.0).max()
    qerr = np.abs(qb - q_full).max()
    print(f'    w={w:2d} ({2*w+1:2d}x{2*w+1:2d})  residual={res:.4e}  '
          f'max|q-q_full|={qerr:.4e}')
    RECORD['windowed'].append({'half_width': w, 'window': 2 * w + 1,
                               'residual': float(res),
                               'max_q_error': float(qerr)})

with open(OUT, 'w', encoding='utf-8') as fh:
    json.dump(RECORD, fh, indent=1)
print('wrote', OUT)
