"""
Thermal crosstalk of a parallel-write spot array in direct laser writing (DLW)
of Sb2S3 phase-change films.

Physics
-------
1. One focused spot: axisymmetric transient heat conduction
       rho*c dT/dt = (1/r) d/dr( r*k*dT/dr ) + d/dz( k*dT/dz ) + q(r,d)
   solved by an implicit finite-volume scheme on a non-uniform grid
   (fine radially near the spot, geometrically coarsened outward, so that the
   thermal diffusion length of every dwell time is inside the domain).
2. An M x M array of identical spots written simultaneously: because the heat
   equation is linear with temperature-independent properties, the temperature
   field is the exact linear superposition of the single-spot responses.

Reported quantity
-----------------
    G(M, p) = T_centre(M x M array) / T_centre(single spot)
i.e. how much the centre pixel is overheated purely because its neighbours are
being written at the same time.  This is the thermal upper bound on the number
of parallel channels that can be used before the written feature size drifts.

Units: SI. All temperatures are reported per 1 mW of absorbed power in the film.
"""

import os
import json
import numpy as np
import scipy.sparse as sp
import scipy.sparse.linalg as spla

# ---------------------------------------------------------------- parameters
LAM      = 532e-9      # wavelength [m]
K_EXT    = 0.06        # amorphous Sb2S3 extinction coefficient at 532 nm
K_TH_A   = 0.19        # amorphous thermal conductivity [W m-1 K-1]
RHO_C_F  = 1.40e6      # volumetric heat capacity [J m-3 K-1]

SUBS = {
    'silica'  : dict(k=1.4,   rho_c=1.05e6),
    'sapphire': dict(k=25.0,  rho_c=3.00e6),
    'silicon' : dict(k=148.0, rho_c=1.70e6),
}

W0    = 0.5e-6         # 1/e^2 spot radius [m]
P_ABS = 1.0e-3         # absorbed power reference [W]
R_IN  = 2.0e-6         # fine radial region [m]
DR0   = 25e-9          # radial step in the fine region [m]

HERE    = os.path.dirname(os.path.abspath(__file__))
OUT_DIR = os.path.join(os.path.dirname(HERE), 'data')


# ------------------------------------------------------------------ meshing
def build_grid(h_film, diffusion_len, dz_film=20e-9, r_growth=1.09,
               n_outer=110):
    """Non-uniform r (fine inside, geometric outside) and z (film + graded sub)."""
    r_outer = max(6.0 * diffusion_len, 4e-6)
    # radial faces
    faces = [0.0]
    r = 0.0
    while r < min(R_IN, r_outer):
        r += DR0
        faces.append(r)
    dr = DR0
    while faces[-1] < r_outer:
        dr *= r_growth
        faces.append(faces[-1] + dr)
    faces = np.array(faces)
    rc = 0.5 * (faces[:-1] + faces[1:])
    vol = 0.5 * (faces[1:]**2 - faces[:-1]**2)     # per 2*pi, per unit dz

    # vertical: film layers then graded substrate
    nf = max(5, int(round(h_film / dz_film)))
    dzf = h_film / nf
    dz = [dzf] * nf
    z = dzf
    dzs = 40e-9
    while z < 0.6 * h_film + max(4 * diffusion_len, 3e-6):
        dz.append(dzs)
        z += dzs
        if z > 2 * h_film + 1e-6:
            dzs *= 1.15
        if z > 80e-6:
            break
    dz = np.array(dz)
    return rc, vol, dz, nf, faces


# ------------------------------------------------------------------- sources
def absorption_density(rc, depth, p_abs, w0, alpha):
    radial = np.exp(-2.0 * rc**2 / w0**2)
    radial /= (np.pi * w0**2 / 2.0)                 # normalised to unit power
    return p_abs * radial * alpha * np.exp(-alpha * depth)


# ------------------------------------------------------------------- solver
def single_spot(h_film, k_sub, rho_c_sub, tau, nt=60, k_film=K_TH_A,
                dz_film=20e-9, verbose=True, t_end=None):
    """Axisymmetric transient solution for one spot.

    t_end=None reproduces the original behaviour (integrate to tau and stop),
    which is what the delivered scan used.  Passing t_end = k*tau extends the
    history past the switch-off so that the cooling tail is available for the
    sequential-scan model; dt is unchanged and the source is applied only while
    t < tau.
    """
    alpha = 4.0 * np.pi * K_EXT / LAM
    D_ref = max(k_sub / rho_c_sub, k_film / RHO_C_F)
    L_th  = np.sqrt(D_ref * tau)

    rc, vol, dz, nf, faces = build_grid(h_film, L_th, dz_film=dz_film)
    nr, nz = len(rc), len(dz)
    zf = np.concatenate(([0.0], np.cumsum(dz)))
    zc = 0.5 * (zf[:-1] + zf[1:])

    k_node = np.where(np.arange(nz) < nf, k_film, k_sub)
    cap    = np.where(np.arange(nz) < nf, RHO_C_F, rho_c_sub)

    n = nr * nz
    rows, cols, vals = [], [], []
    b_static = np.zeros(n)          # source term at full power

    def idx(i, j):
        return j * nr + i

    for j in range(nz):
        for i in range(nr):
            p = idx(i, j)
            diag = 0.0
            V = vol[i] * dz[j]                    # control-volume measure
            # radial coupling
            if i > 0:
                kf = 0.5 * (k_node[j] + k_node[j])
                Gr = k_node[j] * faces[i] * dz[j] / (rc[i] - rc[i - 1])
                diag += Gr
                rows.append(p); cols.append(idx(i - 1, j)); vals.append(-Gr)
            if i < nr - 1:
                Gr = k_node[j] * faces[i + 1] * dz[j] / (rc[i + 1] - rc[i])
                diag += Gr
                rows.append(p); cols.append(idx(i + 1, j)); vals.append(-Gr)
            # axial coupling
            if j > 0:
                km = 0.5 * (k_node[j] + k_node[j - 1])
                Gz = km * vol[i] / (0.5 * (dz[j] + dz[j - 1]))
                diag += Gz
                rows.append(p); cols.append(idx(i, j - 1)); vals.append(-Gz)
            if j < nz - 1:
                km = 0.5 * (k_node[j] + k_node[j + 1])
                Gz = km * vol[i] / (0.5 * (dz[j] + dz[j + 1]))
                diag += Gz
                rows.append(p); cols.append(idx(i, j + 1)); vals.append(-Gz)
            rows.append(p); cols.append(p); vals.append(diag)

            if j < nf:
                b_static[p] = absorption_density(rc[i], zc[j], P_ABS, W0, alpha) * V

    # The axisymmetric control volumes and conductances are expressed per 2*pi.
    # Normalize the discrete source so its *physical* integral over the film is
    # exactly P_ABS, rather than P_ABS times the finite-film absorptance.
    source_power = 2.0 * np.pi * b_static.sum()
    if source_power <= 0.0:
        raise ValueError('Film source has zero integrated power')
    b_static *= P_ABS / source_power

    A = sp.csr_matrix((vals, (rows, cols)), shape=(n, n))
    Cvec = np.zeros(n)
    for j in range(nz):
        Cvec[j * nr:(j + 1) * nr] = cap[j] * vol * dz[j]

    dt = tau / nt
    nsteps = nt if t_end is None else int(round(t_end / dt))
    M = A + sp.diags(Cvec / dt)
    lu = spla.factorized(M.tocsc())

    T = np.zeros(n)
    T_hist = []
    for s in range(nsteps):
        rhs = (b_static if s * dt < tau - 1e-15 else 0.0) + Cvec / dt * T
        T = lu(rhs)
        T_hist.append(T.reshape(nz, nr).copy())

    T_surf = np.array([th[0] for th in T_hist])          # (nt, nr) surface
    T_peak = T_surf.max(axis=0)                          # peak over dwell

    if verbose:
        print(f'  h={h_film*1e9:5.0f} nm  k_sub={k_sub:6.1f}  tau={tau*1e6:6.1f} us  '
              f'L_th={L_th*1e6:6.2f} um  grid={nz}x{nr}  '
              f'peak dT={T_peak[0]:8.2f} K per mW  '
              f'T(1um)/T0={np.interp(1e-6, rc, T_peak)/T_peak[0]:.4f}')
    return rc, T_peak, L_th, T_surf


def sample_radial(distance, rc, profile):
    """Sample the tabulated response and zero contributions beyond its radius."""
    return np.interp(distance, rc, profile, right=0.0)


def crosstalk(T_prof, rc, p, m_half):
    i = np.arange(-m_half, m_half + 1)
    X, Y = np.meshgrid(i, i)
    d = p * np.hypot(X, Y).ravel()
    d = d[d > 0]
    Tn = sample_radial(d, rc, T_prof)
    return 1.0 + Tn.sum() / T_prof[0]


def main():
    os.makedirs(OUT_DIR, exist_ok=True)
    h_list   = [50e-9, 100e-9, 200e-9]
    tau_list = [1e-6, 5e-6, 20e-6, 100e-6]
    p_list   = np.array([0.5, 0.75, 1.0, 1.5, 2.0, 3.0, 4.0, 6.0, 8.0, 12.0]) * 1e-6
    mh_list  = [1, 2, 3, 5, 8, 12, 20, 30]

    rec = []
    print('--- single-spot responses ---')
    cache = {}
    for sub, sp_ in SUBS.items():
        for tau in tau_list:
            for h in h_list:
                rc, Tp, Lth, _ = single_spot(h, sp_['k'], sp_['rho_c'], tau)
                cache[(sub, tau, h)] = (rc, Tp, Lth)
                for p in p_list:
                    for mh in mh_list:
                        G = crosstalk(Tp, rc, p, mh)
                        rec.append(dict(substrate=sub, tau_us=round(tau * 1e6, 2),
                                        h_nm=round(h * 1e9), L_th_um=round(Lth * 1e6, 3),
                                        p_um=round(p * 1e6, 2), M=2 * mh + 1,
                                        G=round(G, 5),
                                        dT_single_K_per_mW=round(Tp[0], 2)))

    with open(os.path.join(OUT_DIR, 'crosstalk_records.json'), 'w', encoding='utf-8') as f:
        json.dump(rec, f)

    # summary: G for the canonical case
    print('\n--- G(M=11, h=100 nm) ---')
    for sub in SUBS:
        for tau in tau_list:
            line = f'{sub:9s} tau={tau*1e6:5.0f}us: '
            for p in [0.5e-6, 1e-6, 2e-6, 4e-6]:
                g = [r['G'] for r in rec if r['substrate'] == sub and
                     r['tau_us'] == round(tau * 1e6, 2) and r['h_nm'] == 100 and
                     r['p_um'] == round(p * 1e6, 2) and r['M'] == 11][0]
                line += f'p={p*1e6:.1f}um G={g:.3f}  '
            print(line)


if __name__ == '__main__':
    main()
