"""Time-step and cooling-tail convergence of raster-speed thresholds."""
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import parallel_thermal_scan as P
from seq_model import G_sequential, lambda_threshold

TAU = 20e-6
PITCH = 1e-6
MH = 5


def root_for(sub, nt, tail):
    sp = P.SUBS[sub]
    rc, tp, _, ts = P.single_spot(100e-9, sp['k'], sp['rho_c'], TAU, nt=nt,
                                  verbose=False, t_end=tail * TAU)
    dt = TAU / nt

    simultaneous = P.crosstalk(tp, rc, PITCH, MH)
    if simultaneous <= 1.05:
        return {'sub': sub, 'nt': nt, 'tail': tail, 'simultaneous_G': simultaneous,
                'lambda_c': None, 'v_min_mm_s': 0.0}
    lam = lambda_threshold(ts, rc, PITCH, MH, TAU, dt, nt)
    return {'sub': sub, 'nt': nt, 'tail': tail, 'simultaneous_G': simultaneous,
            'lambda_c': lam, 'v_min_mm_s': PITCH / (lam * TAU) * 1e3}


def main():
    rows = []
    for sub in ('silica', 'sapphire', 'silicon'):
        for nt, tail in ((30, 8), (60, 8), (120, 8), (60, 4), (60, 16)):
            row = root_for(sub, nt, tail)
            rows.append(row)
            print(row)
    out = os.path.join(os.path.dirname(HERE), 'data', 'raster_time_convergence.json')
    with open(out, 'w', encoding='utf-8') as fh:
        json.dump(rows, fh, indent=1)
    print('wrote', out)


if __name__ == '__main__':
    main()
