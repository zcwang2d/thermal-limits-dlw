# -*- coding: utf-8 -*-
"""Exact minimum scan speed by bisection on G_seq = 1.05 (no grid interpolation)."""

import os
import sys
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import parallel_thermal_scan as P
from seq_model import lambda_threshold

H, TAU, MH, NT = 100e-9, 20e-6, 5, 60
PITCH = 1e-6


def root_for(sub):
    sp = P.SUBS[sub]
    rc, Tp, Lth, TS = P.single_spot(H, sp['k'], sp['rho_c'], TAU, verbose=False,
                                    t_end=8 * TAU)
    dt = TAU / NT

    simultaneous_g = P.crosstalk(Tp, rc, PITCH, MH)
    if simultaneous_g <= 1.05:
        return None, simultaneous_g - 1.05
    lam_c = lambda_threshold(TS, rc, PITCH, MH, TAU, dt, NT)
    v = PITCH / (lam_c * TAU) * 1e3
    return lam_c, v


for sub in ('silica', 'sapphire', 'silicon'):
    lam_c, v = root_for(sub)
    if lam_c is None:
        print(f'{sub:9s} simultaneous G already <= 1.05 (f at 0.05 = {v:.4f}); '
              'v_min = 0 (always)')
    else:
        print(f'{sub:9s} Lambda_c = {lam_c:.4f}  v_min = {v:.2f} mm/s  '
              f'dt = {lam_c*TAU*1e6:.2f} us')
