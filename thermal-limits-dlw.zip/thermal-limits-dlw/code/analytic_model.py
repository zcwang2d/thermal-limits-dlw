# -*- coding: utf-8 -*-
"""Analytic skeleton of the array factor.

The numerical G is a lattice sum of the single-spot Green function.  Split it
into a continuum part (a lattice-density integral, which predicts the 1/p^2
law with no fitted parameter) and a discrete lattice constant that matters
when the pitch is comparable with the source size.
"""

import os
import sys
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import parallel_thermal_scan as P

H = 100e-9
TAU = 20e-6
PITCH = (0.5, 0.75, 1.0, 1.5, 2.0, 3.0, 4.0)
SUBS = ('silica', 'sapphire', 'silicon')


def lattice_G(rc, Tp, T0, p_um, mh):
    i = np.arange(-mh, mh + 1)
    ii, jj = np.meshgrid(i, i, indexing='ij')
    d = (p_um * 1e-6) * np.hypot(ii, jj)
    d = d[~((ii == 0) & (jj == 0))]
    return 1.0 + P.sample_radial(d, rc, Tp).sum() / T0


for sub in SUBS:
    sp = P.SUBS[sub]
    rc, Tp, Lth, TS = P.single_spot(H, sp['k'], sp['rho_c'], TAU, verbose=False)
    T0 = Tp[0]
    f = Tp / T0
    cut = np.where(rc <= 6 * Lth)
    A = 2 * np.pi * np.trapezoid(rc[cut] * f[cut], rc[cut])   # m^2, no fit
    print(f'\n{sub}: L_th = {Lth*1e6:.3f} um, A = {A*1e12:.4f} um^2')
    print('  p(um)  G_num   G_cont=1+A/p^2   rel.dev')
    for p in PITCH:
        Gn = lattice_G(rc, Tp, T0, p, 15)
        Gc = 1 + A / (p * 1e-6) ** 2
        print(f'  {p:4.2f}  {Gn:7.4f}  {Gc:7.4f}        {(Gc-Gn)/Gn*100:+6.1f}%')
