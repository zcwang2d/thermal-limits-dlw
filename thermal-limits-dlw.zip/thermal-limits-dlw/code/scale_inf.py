# -*- coding: utf-8 -*-
"""Infinite-array limit and the array-truncation scaling variable.

G saturates once the array radius exceeds the diffusion length, so the pitch
dependence and the size dependence must be normalised separately:

    G(M,p) - 1 ~ [G_inf(p) - 1] * B(xi),   xi = M*p / (2*L_th)

This script computes G_inf(p) by direct lattice summation on a large array and
then checks whether the normalised ordinate collapses across pitch.
"""

import os
import sys
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import parallel_thermal_scan as P

H, TAU = 100e-9, 20e-6
SUB = 'silica'
sp = P.SUBS[SUB]
rc, Tp, Lth, TS = P.single_spot(H, sp['k'], sp['rho_c'], TAU, verbose=False)
T0 = Tp[0]
prof = Tp / T0

BIG = 80                      # half-width of the summation array


def g_center(MH, p):
    i = np.arange(-MH, MH + 1)
    X, Y = np.meshgrid(i, i)
    d = p * np.hypot(X, Y)
    # Match the production rule: zero outside the tabulated radius and retain
    # only the six-diffusion-length support used for the large-array limit.
    k = np.where(d <= 6.0 * Lth, P.sample_radial(d, rc, prof), 0.0)
    k[MH, MH] = 1.0           # self term exactly 1
    return k.sum()


print(f'infinite-array limit, {SUB}, h=100 nm, tau=20 us, L_th={Lth*1e6:.3f} um')
print(f'{"p[um]":>6s} {"G_inf":>8s} {"pi*p^2*(G_inf-1)":>18s}')
ginf = {}
for p_um in (0.5, 0.75, 1.0, 1.5, 2.0, 3.0, 4.0, 6.0):
    p = p_um * 1e-6
    g = g_center(BIG, p)
    ginf[p_um] = g
    print(f'{p_um:6.2f} {g:8.4f} {np.pi*p*p*1e12*(g-1):18.4f}')

print('\narray truncation collapse:  B = (G-1)/(G_inf-1)  vs  xi = M*p/(2*L_th)')
print(f'{"p[um]":>6s} {"M":>4s} {"xi":>8s} {"G":>8s} {"B":>8s}')
rows = []
for p_um in (0.5, 0.75, 1.0, 1.5, 2.0, 3.0, 4.0):
    p = p_um * 1e-6
    for M in (3, 5, 7, 11, 17, 25, 41, 61):
        g = g_center(M // 2, p)
        xi = M * (p_um * 1e-6) / (2 * Lth)
        B = (g - 1) / (ginf[p_um] - 1)
        rows.append((p_um, M, xi, g, B))
        print(f'{p_um:6.2f} {M:4d} {xi:8.4f} {g:8.4f} {B:8.4f}')

rows = np.array(rows, float)
xi, B = rows[:, 2], rows[:, 4]
A, b = np.polyfit(np.log(xi), np.log(-np.log(np.clip(1 - B, 1e-12, None))), 1)
pred = 1 - np.exp(-np.exp(A * np.log(xi) + b))
res = B - pred
print(f'\nfit B = 1 - exp(-{np.exp(b):.3f} * xi^{A:.3f})')
print(f'  R2 = {1 - (res**2).sum()/((B - B.mean())**2).sum():.4f}   '
      f'max|dev| = {np.abs(res).max():.4f}')

# how well does the normalised ordinate collapse at fixed xi?
print('\ncollapse quality: group by xi bins, report spread of B')
order = np.argsort(xi)
bins = np.array_split(order, 8)
for k, idx in enumerate(bins):
    print(f'  bin {k+1}: xi={xi[idx].min():6.3f}-{xi[idx].max():6.3f}  '
          f'n={idx.size}  B={B[idx].min():.4f}-{B[idx].max():.4f}  '
          f'spread={B[idx].max()-B[idx].min():.4f}')
