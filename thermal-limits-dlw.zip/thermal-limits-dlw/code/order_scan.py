# -*- coding: utf-8 -*-
"""Sequential (raster-scanned) write model.

The delivered scan treats an M x M array as switched on simultaneously, which
is the worst case.  A real DLW tool writes the array point by point, so the
neighbours of a given pixel are written at different instants and have partly
cooled by the time that pixel is exposed.  This script quantifies the
difference, using the cooling tail of the single-spot history.

Definitions
    Lambda = dt_point / tau   (dimensionless point-to-point delay)
    v      = p / dt_point     (scan speed)
A small Lambda recovers simultaneous writing; a large Lambda means the
neighbours have fully cooled and crosstalk vanishes.
"""

import os
import sys
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import parallel_thermal_scan as P
from seq_model import G_sequential

NT = 60
TAU = 20e-6
H = 100e-9
PITCH = 1e-6
MH = 5                      # M = 11
T_END = 8 * TAU


LAMS = (0.1, 0.2, 0.3, 0.5, 0.75, 1.0, 1.5, 2.0, 3.0, 5.0, 10.0)

print('sequential vs simultaneous, h=100 nm, tau=20 us, M=11, p=1.0 um')
print(f'{"substrate":10s} {"Lambda":>7s} {"dt[us]":>8s} {"v[mm/s]":>9s} '
      f'{"G_seq":>8s} {"G_sim":>8s}')
for sub in ('silica', 'sapphire', 'silicon'):
    sp = P.SUBS[sub]
    rc, Tp, Lth, TS = P.single_spot(H, sp['k'], sp['rho_c'], TAU, verbose=False,
                                    t_end=T_END)
    dt = TAU / NT
    # consistency check: reference must use the dwell window only, because the
    # far-field peak of a single spot arrives after switch-off and would
    # otherwise inflate the simultaneous-array value by ~0.35%.
    Tp_win = TS[:NT, :].max(axis=0)
    g_sim_ref = P.crosstalk(Tp_win, rc, PITCH, MH)
    for lam in LAMS:
        g = G_sequential(TS, rc, PITCH, MH, lam, TAU, dt, NT)
        v = PITCH / (lam * TAU) * 1e3          # mm/s
        print(f'{sub:10s} {lam:7.2f} {lam*TAU*1e6:8.2f} {v:9.1f} '
              f'{g:8.4f} {g_sim_ref:8.4f}')
    print('')

# how fast must the stage move to keep G <= 1.05 ?
print('minimum scan speed for G <= 1.05 (p=1.0 um, tau=20 us, M=11)')
for sub in ('silica', 'sapphire', 'silicon'):
    sp = P.SUBS[sub]
    rc, Tp, Lth, TS = P.single_spot(H, sp['k'], sp['rho_c'], TAU, verbose=False,
                                    t_end=T_END)
    dt = TAU / NT
    lam_grid = np.linspace(0.05, 20.0, 80)
    g = [G_sequential(TS, rc, PITCH, MH, l, TAU, dt, NT) for l in lam_grid]
    g = np.array(g)
    hit = np.where(g <= 1.05)[0]
    if hit.size:
        lam_c = lam_grid[hit[0]]
        print(f'  {sub:10s} Lambda >= {lam_c:5.2f}  ->  v >= '
              f'{PITCH/(lam_c*TAU)*1e3:6.2f} mm/s   (dt >= {lam_c*TAU*1e6:.1f} us)')
    else:
        print(f'  {sub:10s} not reached within Lambda <= 20')
