# -*- coding: utf-8 -*-
"""Dose-shaping inverse problem: can crosstalk be cancelled exactly?

Because the heat equation is linear, the peak temperature of every pixel in an
M x M array is a linear map of the per-pixel absorbed power:

    T_a = sum_c K_ac q_c ,   K_ac = T(|r_a - r_c|) / T0

with K_aa = 1 by construction.  Demanding a uniform set-point T* = 1 for every
pixel turns the crosstalk problem into a linear inverse problem

    K q = 1.

If the solution is non-negative, crosstalk is not a ceiling at all: it is a
deterministic bias that pixel-wise power shaping removes exactly.  If the
solution requires negative power, no non-negative dose distribution can
equalise the array, and that pitch is genuinely infeasible.  This script finds
where that boundary lies, and what a finite greyscale costs.
"""

import os
import sys
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import parallel_thermal_scan as P
import json

H = 100e-9
TAU = 20e-6
MH = 5
M = 2 * MH + 1
N = M * M

i = np.arange(-MH, MH + 1)
coords = np.stack(np.meshgrid(i, i, indexing='ij'), -1).reshape(-1, 2)

RECORD = {"film_nm": 100, "dwell_us": 20, "array": "11 x 11",
          "dose_by_pitch": [], "quantisation": []}
OUT = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                   'data', 'dose_inversion.json')

print('dose-shaping inverse problem, silica, h=100 nm, tau=20 us, M=11')
print(f'{"p[um]":>6s} {"G_center":>9s} {"min q":>9s} {"max q":>8s} '
      f'{"neg":>5s} {"sum/N":>8s} {"cond":>9s} {"resid":>8s}')

for sub in ('silica', 'sapphire'):
    sp = P.SUBS[sub]
    rc, Tp, Lth, TS = P.single_spot(H, sp['k'], sp['rho_c'], TAU, verbose=False)
    T0 = Tp[0]
    print(f'\n[{sub}]')
    for p_um in (0.5, 0.75, 1.0, 1.5, 2.0, 3.0, 4.0):
        p = p_um * 1e-6
        d = p * np.hypot(coords[:, None, 0] - coords[None, :, 0],
                         coords[:, None, 1] - coords[None, :, 1])
        K = P.sample_radial(d, rc, Tp) / T0

        T_uniform = K.sum(axis=1)                 # all pixels at q = 1
        g_center = T_uniform[MH * M + MH]

        q = np.linalg.solve(K, np.ones(N))
        neg = int((q < -1e-9).sum())
        resid = np.abs(K @ q - 1.0).max()
        print(f'{p_um:6.2f} {g_center:9.4f} {q.min():9.4f} {q.max():8.4f} '
              f'{neg:5d} {q.sum()/N:8.4f} {np.linalg.cond(K):9.1f} {resid:8.2e}')
        RECORD['dose_by_pitch'].append(
            {'substrate': sub, 'pitch_um': p_um, 'G_center': float(g_center),
             'q_min': float(q.min()), 'q_max': float(q.max()),
             'negative_entries': neg, 'mean_dose': float(q.sum() / N),
             'cond': float(np.linalg.cond(K)), 'residual': float(resid)})

    # finite greyscale: quantise q and measure the resulting temperature spread
    print(f'\n[{sub}] residual temperature spread after quantising q '
          f'(p = 1.0 um)')
    p = 1e-6
    d = p * np.hypot(coords[:, None, 0] - coords[None, :, 0],
                     coords[:, None, 1] - coords[None, :, 1])
    K = P.sample_radial(d, rc, Tp) / T0
    q = np.linalg.solve(K, np.ones(N))
    qlo, qhi = q.min(), q.max()
    for nlev in (8, 16, 64, 256, 1024):
        qq = qlo + np.round((q - qlo) / (qhi - qlo) * (nlev - 1)) / (nlev - 1) * (qhi - qlo)
        Tq = K @ qq
        print(f'  levels={nlev:5d}  T/T*: min={Tq.min():.4f} max={Tq.max():.4f}  '
              f'spread={100*(Tq.max()-Tq.min())/1.0:5.2f}%  '
              f'power={qq.sum()/N:.4f}')
        RECORD['quantisation'].append(
            {'substrate': sub, 'levels': nlev, 'T_min': float(Tq.min()),
             'T_max': float(Tq.max()),
             'spread_percent': float(100 * (Tq.max() - Tq.min())),
             'power': float(qq.sum() / N)})

with open(OUT, 'w', encoding='utf-8') as fh:
    json.dump(RECORD, fh, indent=1)
print('wrote', OUT)
