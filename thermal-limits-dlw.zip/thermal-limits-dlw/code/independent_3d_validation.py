"""Independent 3-D multi-source verification of the superposition model.

A fully implicit three-dimensional finite-volume heat solver is used for one
isolated spot and for a simultaneous 3 x 3 array. The same sparse factorization
is reused for both cases. The direct 3-D result is compared with algebraic
superposition and with the independent axisymmetric production solver.
"""
import json
import os
import sys

import numpy as np
import scipy.sparse as sp
import scipy.sparse.linalg as spla

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import parallel_thermal_scan as axi


def solve_3d(dx_um=0.25, nt=60, tau=20e-6, half_width_um=6.0):
    dx = dx_um * 1e-6
    dy = dx
    half_width = half_width_um * 1e-6
    xy = np.arange(-half_width, half_width + 0.5 * dx, dx)
    nx = len(xy)
    ny = nx
    z_faces = np.concatenate((np.linspace(0.0, 100e-9, 6), [140e-9]))
    while z_faces[-1] < 25e-6:
        z_faces = np.append(z_faces, z_faces[-1] * 1.25)
    dz_layers = np.diff(z_faces)
    nz = len(dz_layers)
    nf = 5
    zc = 0.5 * (z_faces[:-1] + z_faces[1:])
    kz = np.where(np.arange(nz) < nf, axi.K_TH_A, 1.4)
    cap = np.where(np.arange(nz) < nf, axi.RHO_C_F, 1.05e6)
    n = nx * ny * nz

    rows, cols, vals = [], [], []
    b = np.zeros(n)
    dt = tau / nt
    cvec = np.zeros(n)

    def idx(i, j, k):
        return i + nx * (j + ny * k)

    for k in range(nz):
        dz = dz_layers[k]
        for j in range(ny):
            for i in range(nx):
                p = idx(i, j, k)
                volume = dx * dy * dz
                cvec[p] = cap[k] * volume
                diag = 0.0
                for di, dj, dk, conductance in (
                    (-1, 0, 0, kz[k] * dy * dz / dx),
                    (1, 0, 0, kz[k] * dy * dz / dx),
                    (0, -1, 0, kz[k] * dx * dz / dy),
                    (0, 1, 0, kz[k] * dx * dz / dy),
                ):
                    ii, jj = i + di, j + dj
                    if 0 <= ii < nx and 0 <= jj < ny:
                        q = idx(ii, jj, k)
                        diag += conductance
                        rows.append(p); cols.append(q); vals.append(-conductance)
                if k > 0:
                    km = 0.5 * (kz[k] + kz[k - 1])
                    distance = 0.5 * (dz + dz_layers[k - 1])
                    conductance = km * dx * dy / distance
                    diag += conductance
                    rows.append(p); cols.append(idx(i, j, k - 1)); vals.append(-conductance)
                if k < nz - 1:
                    km = 0.5 * (kz[k] + kz[k + 1])
                    distance = 0.5 * (dz + dz_layers[k + 1])
                    conductance = km * dx * dy / distance
                    diag += conductance
                    rows.append(p); cols.append(idx(i, j, k + 1)); vals.append(-conductance)
                rows.append(p); cols.append(p); vals.append(diag)

    a = sp.csr_matrix((vals, (rows, cols)), shape=(n, n))
    lu = spla.factorized((a + sp.diags(cvec / dt)).tocsc())
    alpha = 4.0 * np.pi * axi.K_EXT / axi.LAM
    xx, yy = np.meshgrid(xy, xy, indexing='ij')

    def source(cx, cy):
        radial = np.exp(-2.0 * ((xx - cx) ** 2 + (yy - cy) ** 2) / axi.W0 ** 2)
        radial /= np.pi * axi.W0 ** 2 / 2.0
        out = np.zeros(n)
        for k in range(nf):
            density = radial * alpha * np.exp(-alpha * zc[k]) * dx * dy * dz_layers[k]
            for j in range(ny):
                for i in range(nx):
                    out[idx(i, j, k)] = density[i, j]
        out *= axi.P_ABS / out.sum()
        return out

    def run(sources):
        heat = sum((source(x, y) for x, y in sources), np.zeros(n))
        temperature = np.zeros(n)
        surface = []
        for _ in range(nt):
            temperature = lu(heat + cvec / dt * temperature)
            field = temperature.reshape(nz, ny, nx)
            surface.append(field[0].copy())
        return np.array(surface)

    single = run([(0.0, 0.0)])
    offsets = [-1e-6, 0.0, 1e-6]
    sources = [(x, y) for x in offsets for y in offsets]
    multiple = run(sources)
    centre = int(round((nx - 1) / 2))
    single_peak = single[:, centre, centre].max()
    direct_peak = multiple[:, centre, centre].max()

    # Algebraic superposition of the 3-D single-source field.
    superposed = np.zeros_like(single)
    for ox, oy in sources:
        sx, sy = int(round(ox / dx)), int(round(oy / dy))
        shifted = np.roll(single, (sx, sy), axis=(1, 2))
        if sx > 0:
            shifted[:sx, :, :] = 0.0
        elif sx < 0:
            shifted[sx:, :, :] = 0.0
        if sy > 0:
            shifted[:, :sy, :] = 0.0
        elif sy < 0:
            shifted[:, sy:, :] = 0.0
        superposed += shifted
    superposed_peak = superposed[:, centre, centre].max()

    rc, tp, _, _ = axi.single_spot(100e-9, 1.4, 1.05e6, tau, nt=nt, verbose=False)
    axis_g = float(axi.crosstalk(tp, rc, 1e-6, 1))
    axis_peak = float(tp[0])
    direct_g = direct_peak / single_peak
    superposed_g = superposed_peak / single_peak
    return {
        'dx_um': dx_um,
        'half_width_um': half_width_um,
        'nt': nt,
        'grid': [nx, ny, nz],
        'single_peak_K_per_mW': float(single_peak),
        'direct_3d_peak_K_per_mW': float(direct_peak),
        'superposed_3d_peak_K_per_mW': float(superposed_peak),
        'direct_3d_G': float(direct_g),
        'superposed_3d_G': float(superposed_g),
        'axisymmetric_G': axis_g,
        'axisymmetric_peak_K_per_mW': axis_peak,
        'direct_vs_axisymmetric_G_rel_diff': float(direct_g / axis_g - 1.0),
        'direct_vs_superposed_G_rel_diff': float(direct_g / superposed_g - 1.0),
        'direct_vs_superposed_peak_rel_diff': float(direct_peak / superposed_peak - 1.0),
    }


def main():
    if len(sys.argv) == 1:
        # Reproduce the complete two-mesh record used in the manuscript.
        result = {
            'description': ('Independent fully implicit 3-D finite-volume verification '
                            'for a simultaneous 3 x 3 array on silica, h = 100 nm, '
                            'tau = 20 us, p = 1 um. The direct 3-D result is compared '
                            'with algebraic superposition and the axisymmetric production '
                            'solver, with both solvers normalized to actual absorbed power.'),
            'runs': [solve_3d(dx_um=0.25, nt=60), solve_3d(dx_um=0.20, nt=60)],
        }
        out = os.path.join(os.path.dirname(HERE), 'data',
                           'independent_3d_validation.json')
    else:
        dx_um = float(sys.argv[1])
        nt = int(sys.argv[2]) if len(sys.argv) > 2 else 60
        half_width_um = float(sys.argv[3]) if len(sys.argv) > 3 else 6.0
        result = solve_3d(dx_um=dx_um, nt=nt, half_width_um=half_width_um)
        suffix = f'_dx{dx_um:g}_w{half_width_um:g}'
        out = os.path.join(os.path.dirname(HERE), 'data',
                           f'independent_3d_validation{suffix}.json')
    with open(out, 'w', encoding='utf-8') as fh:
        json.dump(result, fh, indent=1)
    print(json.dumps(result, indent=2))
    print('wrote', out)


if __name__ == '__main__':
    main()
